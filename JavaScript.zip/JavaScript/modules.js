let num1 = 11;
let num2 = 3;


console.log(num1 / num2);
console.log(num1 % num2);

function evenOrOddNo(num){

    if(num % 2 === 0)
        return num + " is even number."
    else 
        return num + " is odd number."
}

console.log(evenOrOddNo(23));   
console.log(evenOrOddNo(0));




'/storage/emulated/0/Download/2023-12-29-12-56-25-062.jpeg'

'content://com.miui.gallery.open/raw/%2Fstorage%2Femulated%2F0%2FDownload%2F2023-12-29-12-56-25-062.jpeg'