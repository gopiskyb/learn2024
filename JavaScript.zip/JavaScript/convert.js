document.addEventListener('DOMContentLoaded', function () {
    let txtNumber = document.getElementById('txtNumber');
    let baseDDL = document.getElementById('base');
    let buttonClick = document.getElementById('buttonClick');
    let output = document.getElementById('convertedValue');

    buttonClick.addEventListener('click', function () {
        let num = +txtNumber.value;
        let base = +baseDDL.value;
    
        if(isNaN(num)){
            output.textContent = "Invalid number";
            output.style.color = "#C2E7FF";
        } else {
            let convertValue = num.toString(base);
            output.textContent = convertValue.toUpperCase();
            output.style.color = "#000"
            output.style.fontWeight = "bold"
        }
    });
});
