let checkBtn = document.querySelector('.btn-dark');
let newGameBtn = document.querySelector('.btn-outline-dark');
let attemptsLeftEl = document.querySelector('#attempt-left');
let currentScoreEl = document.querySelector('#current-score');
let currentHighScore = document.querySelector('.current-high-score');
let secretNumber = document.querySelector('.secret-number');
let txtNumber = document.querySelector('.input-number');
let displayMessage = document.querySelector('.message');
let body = document.querySelector('.game-container');

let secretNumberValue = Math.trunc(Math.random() * 20) + 1;
console.log(secretNumberValue);
let currentScore = 20;
let attemptsLeft = 10;
let highScore = 0;

checkBtn.addEventListener('click', function(){

    if(attemptsLeft > 0){
        attemptsLeft--;
        attemptsLeftEl.textContent = attemptsLeft;

        let guess = Number(txtNumber.value);

        if(guess === 0){
            displayMessage.textContent = 'No number or 0 entered!';
            body.style.backgroundColor = '#EF4040';
            setTimeout(() => {
                body.style.backgroundColor = '#FFF';
            }, 500);
        }   
        else if(guess == secretNumberValue){
            displayMessage.textContent = 'You won the game.';
            secretNumber.textContent = secretNumberValue;
            body.style.backgroundColor = '#A2FF86';
            highScore = currentScore > highScore ? currentScore : highScore;
            currentHighScore.textContent = highScore;
        }
        else if(guess !== secretNumberValue){
            if(currentScore > 0){
                body.style.backgroundColor = '#EF4040';
                setTimeout(() => {
                    body.style.backgroundColor = '#FFF';
                }, 500);
                let message = guess > secretNumberValue ? 'You guessed too high' : 'You guessed to low';
                displayMessage.textContent = message;
                currentScore--;
                currentScoreEl.textContent = currentScore;
            }
            else {
                displayMessage.textContent = "You lost the game!";
                currentScoreEl.textContent = 0;
                body.style.backgroundColor = '#EF4040';
            }
        }
    }
    else{
        displayMessage.textContent = "You lost the game!";
        attemptsLeft.textContent = 0;
        body.style.backgroundColor = '#EF4040';
    }
});

newGameBtn.addEventListener('click', function(){
    secretNumberValue = Math.trunc(Math.random() * 20) + 1;
    currentScore = 20;
    attemptsLeft = 10;
    displayMessage.textContent = 'Guess a number between 1 - 20'
    currentScoreEl.textContent = currentScore;
    attemptsLeftEl.textContent = attemptsLeft;
    secretNumber.textContent = '?';
    txtNumber.value = '';
    body.style.backgroundColor = '#FFF';
});