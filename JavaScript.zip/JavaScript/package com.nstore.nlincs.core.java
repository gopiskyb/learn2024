package com.nstore.nlincs.core.fragment;

import static com.nstore.nlincs.core.fragment.ManageProductFragment.mLog;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.nstore.nlincs.core.BuildConfig;
import com.nstore.nlincs.core.R;
import com.nstore.nlincs.core.adapter.DisplayLogisitcsItemAdapter;
import com.nstore.nlincs.core.activity.Displaybill;
import com.nstore.nlincs.core.adapter.DisplayshipmentAdapter;
import com.nstore.nlincs.core.adapter.LogisticAdapter;
import com.nstore.nlincs.core.app.App;
import com.nstore.nlincs.core.appConfig.appConstant;
import com.nstore.nlincs.core.dialogs.CustomDialog;
import com.nstore.nlincs.core.model.DeliveryDetailsData;
import com.nstore.nlincs.core.model.DeliveryInvoiceModel;
import com.nstore.nlincs.core.model.DeliveryItemData;
import com.nstore.nlincs.core.model.LogisticsPartner;
import com.nstore.nlincs.core.model.Order;
import com.nstore.nlincs.core.model.OrderItem;
import com.nstore.nlincs.core.model.SalesOrder;
import com.nstore.nlincs.core.model.ShipmentData;
import com.nstore.nlincs.core.ondc.LogisticsUtils;
import com.nstore.nlincs.core.ondc.model.LogisticsItem;
import com.nstore.nlincs.core.model.WalletData;
import com.nstore.nlincs.core.ondc.model.Price;
import com.nstore.nlincs.core.preference.AppPreference;
import com.nstore.nlincs.core.salesReturn.ReturnRequestAdapter;
import com.nstore.nlincs.core.service.InventorySync;
import com.nstore.nlincs.core.utility.BasicUtils;
import com.nstore.nlincs.core.utility.InputFilterDecimal;
import com.nstore.nlincs.core.utility.InputFilterMinMax;
import com.nstore.nlincs.core.utility.JsonDataParser;
import com.nstore.nlincs.core.volley.VolleyHttpRequest;
import com.nstore.nlincs.core.volley.VolleyTaskListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class ShipmentDialogFragment extends DialogFragment implements VolleyTaskListener, DisplayshipmentAdapter.GetDeliveryPartnerDetail, LogisticAdapter.update,
        DisplayLogisitcsItemAdapter.LogisticsItemSelectedListener {
    private SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
    private DatePickerDialog datePickerDialog;
    Date date = new Date();
    private Calendar c = Calendar.getInstance();
    private SimpleDateFormat dateFormatter;
    private String strDate = "";
    private int int_pYear = 0, int_pMonth = 0, int_pDay = 0;
    TextView tv_shipment_Date;
    Button btn_save, btn_cancel;
    RadioButton rb_select_today, rb_select_otherday;
    String delivery_partner_name = "";
    SendDeliveryDetails sendDeliveryDetails;
    SendReturnDetails sendReturnDetails;
    ReturnRequestAdapter.ReturnStatusUpdateListener returnStatusUpdateListener;
    DisplayshipmentAdapter displayshipmentAdapter;
    DisplayLogisitcsItemAdapter displayLogisitcsItemAdapter;
    RecyclerView delivery_partner_recycler;
    LinearLayout deliveryPriceLayout;
    TextView txtDeliveryHeader;
    RecyclerView logisticsPriceRecycler;
    ProgressBar progressBar;

    private ArrayList<LogisticsPartner> logisticList = new ArrayList<>();
    private CustomDialog dialog = new CustomDialog();
    private LogisticAdapter.update ondcListener;
    private LogisticsPartner selectedLogisticsPartner = new LogisticsPartner();
    private String so_key;
    private int key,diKey, soKey;
    private String di_key, orderStatus;
    private int orderPosition;
    private JSONObject logisticsOnSearchData;
    private String selectedProvider;
    private JSONObject logisticsOnInitData;
    private JSONObject logisticsOnConfirmData, jsonObjectConfirm ;
    private JSONObject logisticsOnTrackData;
    private Order order;
    private DeliveryItemData deliveryitem;
    private LinearLayout layoutChooseDate, linearLayout_logistic_price, linearLayoutPackageDetail,
            linearWeightHeight, linearLengthBreath;
    private TextView txtSelectedOndcPartner;
    private TextView txtProgress, textViewCheapest, textViewFastest, textViewPreferred;
    private Boolean isShipmentApiCalled = false;
    private Context mContext;
//    private String[] ondc_category = new String[]{"Standard Delivery", "Express Delivery", "Immediate Delivery", "Same Day Delivery", "Next Day Delivery"};
    LinearLayout linearRadioGrp, linearCheapest, linearFastest, linearPreferred;
    SwitchCompat switchCheapest, switchFastest, switchPreferred;

    TextView textView_logistic_partnerName, textView_logistic_price, textView_logistic_desc_name,
            textView_choose_partner, txtPackageDetail;

    String item_id, name, currency, value, providerName, transactionId, partner_name, selected_subscriber_id, category_id, fulfillment_id;
    boolean isCheapest = false, isFastest = false, isPreferred = false;

    EditText editTextWeight, editTextHeight, editTextLength, editTextBreadth;

    String height, weight, length, breadth;

    View id_view_package, view_date_id;
    CheckBox checkBox_markAsPacked;
    List<DeliveryItemData> deliveryitemList = new ArrayList<>();
    private DecimalFormat decimalFormat = new DecimalFormat("##0.00");

    private final BroadcastReceiver mLogisticsReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String key = intent.getStringExtra("key");
            if (!TextUtils.isEmpty(key)) {
                String data = intent.getStringExtra("data");
                mLog.info("ShipmentDialogFragment Received " + key + " - " + JsonDataParser.getJsonObject(data));

                if (key.equalsIgnoreCase("ON_SEARCH")) {
                    selected_subscriber_id = selectedLogisticsPartner.getSubscriber_id();
//                    Log.i("selected_subscriber_id : ",selected_subscriber_id);
                    JSONObject mLogisticsData = JsonDataParser.getJsonObject(data);
                    if (mLogisticsData != null) {
                        String bpp_id = LogisticsUtils.getBppId(mLogisticsData);
                        mLog.info("received_subscriber_id : " + bpp_id);
                        if (!TextUtils.isEmpty(selected_subscriber_id) && !TextUtils.isEmpty(bpp_id)) {
                            mLog.info("bpp_id : " + bpp_id);
                            if (selected_subscriber_id.equalsIgnoreCase(bpp_id)) {
                                hideProgressDialog();
                                String errorMsg = LogisticsUtils.getErrorMessage(mLogisticsData);

                                if (mLogisticsData.has("message") && TextUtils.isEmpty(errorMsg)) {
                                    logisticsOnSearchData = mLogisticsData;
                                    Map<String, List<LogisticsItem>> providers = LogisticsUtils.getLogisticsProviderData(logisticsOnSearchData);
                                    if (providers.size() > 0) {
                                        loadLogisticsItems(providers);
                                        btn_save.setText("Generate Shipment");
                                    } else {
                                        showToast("Price Details not found");
                                        btn_save.setText("Search Price");
                                    }
                                } else {
                                    if (mLogisticsData.has("error")) {
                                        try {
                                            JSONObject json = mLogisticsData.getJSONObject("error");
                                            showToast("" + json.getString("message"));
                                        } catch (JSONException e) {
                                            Log.e("error", e.toString());
                                        }
                                        btn_save.setText("Search Price");
                                    }
                                }
                            }
//                            else{
//                                hideProgressDialog();
//                                mLog.info("Invalid subscriber ID : "+bpp_id);
//                            }
                        }
                    } else {
                        hideProgressDialog();
                        showToast("Invalid data received");
                    }

                } else if (key.equalsIgnoreCase("ON_INIT")) {

                    logisticsOnInitData = JsonDataParser.getJsonObject(data);
                    logisticsOnConfirmData = null;
                    String errorMsg = LogisticsUtils.getErrorMessage(logisticsOnInitData);

                    if (order != null && deliveryitem != null && TextUtils.isEmpty(errorMsg)) {
                        fireForOndcRequest(appConstant.ONDC_LOGISTIC_CONFIRM, logisticsOnInitData, order, deliveryitem, selectedlogisticsItem);
                    } else {
                        hideProgressDialog();
                        showToast("Shipment quote request details not available");
                    }
                } else if (key.equalsIgnoreCase("ON_CONFIRM")) {
                    mLog.info("Inside On_Confirm check");
                    logisticsOnConfirmData = JsonDataParser.getJsonObject(data);
                    logisticsOnTrackData = null;
                    JSONObject jsoOrder = LogisticsUtils.getOrder(logisticsOnConfirmData);
                    String errorMsg = LogisticsUtils.getErrorMessage(logisticsOnConfirmData);
                    hideProgressDialog();

                    mLog.info("logistics Data : " + logisticsOnConfirmData);

                    if (jsoOrder != null && TextUtils.isEmpty(errorMsg)) {
                        String order_id = JsonDataParser.getStringValueFromJSON(jsoOrder, "id");
                        String state = JsonDataParser.getStringValueFromJSON(jsoOrder, "state");
                        mLog.info("Order id : " + order_id);
                        mLog.info("Order state : " + state);
                        if (LogisticsUtils.Order_State.contains(state.toLowerCase())) {
                            sendDeliveryDetails.callGetShipmentAPI();
//                            hideProgressDialog();
                            showToast("Shipment created successfully");
                            dismiss();
                        } else {
                            showToast("Unable to create shipment. Please try again.");
                            hideProgressDialog();
                            dismiss();
                        }
                    } else {
                        errorMsg = LogisticsUtils.getErrorMessage(logisticsOnConfirmData);
                        mLog.severe("**** ON_CONFIRM Error : " + errorMsg);
                        hideProgressDialog();
                        showToast(errorMsg);
                        logisticsOnConfirmData = null;
                    }
                } else if (key.equalsIgnoreCase("on_update")) {
                    hideProgressDialog();
                    showToast("Shipment created successfully");
                    dismiss();
                }
//                else if (key.equalsIgnoreCase("ON_STATUS")) {
//                    JSONObject logisticsOnSearchData = JsonDataParser.getJsonObject(data);
//                    mLog.info("logisticsOnTrackData : " + logisticsOnTrackData);
//                    String errorMsg = LogisticsUtils.getErrorMessage(logisticsOnConfirmData);
//                    if (!TextUtils.isEmpty(errorMsg)) {
//                        hideProgressDialog();
//                        Toast.makeText(getActivity(), "Generate shipment was not processed. Please try again", Toast.LENGTH_SHORT).show();
//                    }
//
//                }
                else if (key.equalsIgnoreCase("ON_TRACKK")) {
                    hideProgressDialog();
                    logisticsOnTrackData = JsonDataParser.getJsonObject(data);
                    mLog.info("logisticsOnTrackData : " + logisticsOnTrackData);
                    JSONObject onTrackMessage = LogisticsUtils.getMessage(logisticsOnTrackData);
                    String errorMsg = LogisticsUtils.getErrorMessage(logisticsOnTrackData);

                    JSONObject tracking = null;
                    if (onTrackMessage != null && TextUtils.isEmpty(errorMsg))
                        tracking = JsonDataParser.getJsonValueFromJSON(onTrackMessage, "tracking");

                    JSONObject mContext = LogisticsUtils.getContext(logisticsOnTrackData);
                    String bpp_id = JsonDataParser.getStringValueFromJSON(mContext, "bpp_id");
                    String bpp_uri = JsonDataParser.getStringValueFromJSON(mContext, "bpp_uri");

                    JSONObject shipmentOrder = LogisticsUtils.getOrder(logisticsOnConfirmData);
//                    JSONObject initOrder = LogisticsUtils.getOrder(logisticsOnInitData);
//                    JSONObject init_payment = JsonDataParser.getJsonValueFromJSON(initOrder, "payment");
//                    JSONObject payment_params = JsonDataParser.getJsonValueFromJSON(init_payment, "params");
//                    String shipment_amount = JsonDataParser.getStringValueFromJSON(payment_params, "amount");

                    String shipment_amount = "";
                    if (shipmentOrder != null) {
                        JSONObject quote = JsonDataParser.getJsonValueFromJSON(shipmentOrder, "quote");
                        if (quote != null) {
                            JSONObject jsoPrice = JsonDataParser.getJsonValueFromJSON(quote, "price");
                            if (jsoPrice != null) {
                                Price price = new Gson().fromJson(jsoPrice.toString(), Price.class);
                                if (price != null) {
                                    shipment_amount = price.getValue();
                                }
                            }
                        }
                    }

                    if (!isShipmentApiCalled) {
                        isShipmentApiCalled = true;
                        sendDeliveryDetails.sendOndcDeliveryDetails(delivery_partner_name, bpp_id, bpp_uri, shipmentOrder, shipment_amount, tracking);
                    }

                    logisticsOnSearchData = null;
                    logisticsOnInitData = null;
                    logisticsOnConfirmData = null;
                    logisticsOnTrackData = null;
                    dismiss();
                }
            }
        }
    };

    private LogisticsItem selectedlogisticsItem;
    private AppPreference appPreference;
    private DatePickerDialog.OnDateSetListener pDateSetListener1 = new DatePickerDialog.OnDateSetListener() {

        @SuppressLint("SimpleDateFormat")
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {

            @SuppressWarnings("deprecation")
            Date selectedDate = new Date(year - 1900, monthOfYear, dayOfMonth);// selected
            // date
            // Log.d("Selected Date", ""+selectedDate);

            dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
            strDate = dateFormatter.format(selectedDate);// date format to
            // display to user
//             Log.d("strEnteredDate", ""+strDate);

            SimpleDateFormat dateFormatter1 = new SimpleDateFormat("dd");
            String str_date = dateFormatter1.format(selectedDate);// Separated
            // day

            SimpleDateFormat dateFormatter2 = new SimpleDateFormat("MM");
            String str_Month = dateFormatter2.format(selectedDate);// Separated
            // month

            SimpleDateFormat dateFormatter3 = new SimpleDateFormat("yyyy");
            String str_Year = dateFormatter3.format(selectedDate);// Separated


            Calendar c = Calendar.getInstance();
            String str_curDate = dateFormatter.format(c.getTime());// get

            // current
            // date
            Date dt_curdate = null, dt_enteredDate = null;
            try {
                dt_curdate = dateFormatter.parse(str_curDate);// current date
                dt_enteredDate = dateFormatter.parse(strDate);// entered date
            } catch (ParseException e) {
                // Log.e("error",e.toString());
            }

            // selected date should after or equals to current date
            if ((dt_enteredDate.after(dt_curdate) || dt_enteredDate
                    .equals(dt_curdate))) {
                tv_shipment_Date.setText("Delivery Date : " + strDate);

                if (!TextUtils.isEmpty(strDate)) {
                } else {
                    tv_shipment_Date.setText(null);
                }

            } else { // show error message & make empty

                tv_shipment_Date.setText(null);
//                txtDateSearch.setError(getResources().getString(R.string.err_entered_future_dt));
                Toast.makeText(getActivity(), "Please enter the correct date", Toast.LENGTH_SHORT).show();
            }

        }
    };

    private boolean isFromOrderScreen = false, isFromSalesReturn = false;
    private String orderScreenSelectedDeliveryPartner;
    private String transaction_Id; //item_Id
    List<DeliveryItemData> deliveryItemList;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mLogisticsReceiver, new IntentFilter("ONDC_LOGISTICS"));
        appPreference = AppPreference.getAppSharedPrefrencesInstace();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ondcListener = ShipmentDialogFragment.this;
        mContext = ShipmentDialogFragment.this.getActivity();
        View view = inflater.inflate(R.layout.ns_fragment_shipment_dialog, container, false);
        initView(view);
        return view;
    }

    private void initView(View view) {
        getCurrentdate();
        strDate = df.format(date);
        progressBar = view.findViewById(R.id.progressBar);
        btn_save = view.findViewById(R.id.btn_save);
        btn_cancel = view.findViewById(R.id.btn_cancel);
        delivery_partner_recycler = view.findViewById(R.id.delivery_partner_recycler);
        tv_shipment_Date = view.findViewById(R.id.tv_shipment_Date);
        rb_select_today = view.findViewById(R.id.rb_select_today);
        rb_select_otherday = view.findViewById(R.id.rb_select_otherday);
        rb_select_today.setChecked(true);

        Bundle bundle = getArguments();
        so_key = bundle.getString("so_key", "");
        di_key = bundle.getString("di_key", "");
        orderStatus = bundle.getString("order_status", "");
        orderPosition = bundle.getInt("order_position");

        isFromOrderScreen = bundle.getBoolean("isFromOrderScreen");
        isFromSalesReturn = bundle.getBoolean("isFromSalesReturn");
        key = bundle.getInt("key");
        diKey = bundle.getInt("diKeyReturn");
        soKey = bundle.getInt("soKeyReturn");
        deliveryItemList = new ArrayList<>();
        deliveryItemList = bundle.getParcelableArrayList("deliveryList");
        if (isFromOrderScreen)
            orderScreenSelectedDeliveryPartner = bundle.getString("delivery_partner");
        else orderScreenSelectedDeliveryPartner = null;

        tv_shipment_Date.setText("Delivery Date : " + strDate);
        layoutChooseDate = view.findViewById(R.id.lay_choose_date);
        txtSelectedOndcPartner = view.findViewById(R.id.ondc_delivery_partner);
        txtProgress = view.findViewById(R.id.progress_text);
        txtDeliveryHeader = view.findViewById(R.id.delivery_header_label);

        linearRadioGrp = view.findViewById(R.id.linearRadioGrp);
        linearCheapest = view.findViewById(R.id.linearCheapest);
        linearFastest = view.findViewById(R.id.linearFastest);
        linearPreferred = view.findViewById(R.id.linearPreferred);
        switchCheapest = view.findViewById(R.id.switchCheapest);
        switchFastest = view.findViewById(R.id.switchFastest);
        switchPreferred = view.findViewById(R.id.switchPreferred);
        textViewCheapest = view.findViewById(R.id.textViewCheapest);
        textViewFastest = view.findViewById(R.id.textViewFastest);
        textViewPreferred = view.findViewById(R.id.textViewPreferred);

        linearLayout_logistic_price = view.findViewById(R.id.linearLayout_logistic_price);
        textView_logistic_partnerName = view.findViewById(R.id.textView_logistic_partnerName);
        textView_logistic_price = view.findViewById(R.id.textView_logistic_price);
        textView_logistic_desc_name = view.findViewById(R.id.textView_logistic_desc_name);
        textView_choose_partner = view.findViewById(R.id.textView_choose_partner);

//        linearLayoutPackageDetail = view.findViewById(R.id.linearlayoutPackageDetail);
        id_view_package = view.findViewById(R.id.id_view_package);
        view_date_id = view.findViewById(R.id.view_date_id);
        linearLengthBreath = view.findViewById(R.id.linearLengthBreath);
        linearWeightHeight = view.findViewById(R.id.linearWeightHeight);
        txtPackageDetail = view.findViewById(R.id.txtPackageDetail);
        editTextHeight = view.findViewById(R.id.editTextHeight);
        editTextWeight = view.findViewById(R.id.editTextWeight);
        editTextLength = view.findViewById(R.id.editTextLength);
        editTextBreadth = view.findViewById(R.id.editTextBreadth);

        editTextHeight.setFilters(new InputFilter[]{
                new InputFilterDecimal(5, 2), new InputFilterMinMax("0", "999.99")
        });
        editTextWeight.setFilters(new InputFilter[]{
                new InputFilterDecimal(5, 2), new InputFilterMinMax("0", "999.99")
        });
        editTextLength.setFilters(new InputFilter[]{
                new InputFilterDecimal(5, 2), new InputFilterMinMax("0", "999.99")
        });
        editTextBreadth.setFilters(new InputFilter[]{
                new InputFilterDecimal(5, 2), new InputFilterMinMax("0", "999.99")
        });

        checkBox_markAsPacked = view.findViewById(R.id.checkBox_markAsPacked);

//        switchCheapFastest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if(isChecked){
//                   textViewCheapFastest.setText("Fastest");
//                }
//                else {
//                    textViewCheapFastest.setText("Cheapest");
//                }
//                radioPreferred.setChecked(false);
//            }
//        });
        switchCheapest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isCheapest = true;
                    switchFastest.setChecked(false);
                }
                else{
                    isCheapest = false;
                    deliveryPriceLayout.setVisibility(View.GONE);
                    btn_save.setText("Search Price");
                }
            }
        });

        switchFastest.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    isFastest = true;
                    switchCheapest.setChecked(false);
                }
                else{
                    isFastest = false;
                    deliveryPriceLayout.setVisibility(View.GONE);
                    btn_save.setText("Search Price");
                }
            }
        });

        switchPreferred.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    showPreferredMethod();
                    isPreferred = true;
                }
                else {
                    txtSelectedOndcPartner.setVisibility(View.GONE);
                    deliveryPriceLayout.setVisibility(View.GONE);
                    btn_save.setText("Search Price");
                    isPreferred = false;
                }
            }
        });

        rb_select_today.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strDate = df.format(date);
                tv_shipment_Date.setText("Delivery Date : " + strDate);
            }
        });

        rb_select_otherday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (datePickerDialog == null) {
                    datePickerDialog = new DatePickerDialog(getActivity(), pDateSetListener1, int_pYear,
                            int_pMonth, int_pDay);
                    datePickerDialog.setButton(DialogInterface.BUTTON_NEUTRAL, "Clear", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            strDate = df.format(date);
                            rb_select_today.setChecked(true);
                            tv_shipment_Date.setText("Delivery Date : " + strDate);
                        }
                    });
                    datePickerDialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            strDate = df.format(date);
                            rb_select_today.setChecked(true);
                            tv_shipment_Date.setText("Delivery Date : " + strDate);
                        }
                    });
                }
                datePickerDialog.getDatePicker().setMinDate(c.getTimeInMillis());
                datePickerDialog.show();
            }
        });

            deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
            if (deliveryitemList.size() > 0) {
                this.deliveryitem = deliveryitemList.get(0);
                if (di_key.equals(String.valueOf(deliveryitem.getDi_key()))
                        && orderStatus.equalsIgnoreCase("ready_to_ship")
                        /*&& orderScreenSelectedDeliveryPartner != null
                        && orderScreenSelectedDeliveryPartner.equalsIgnoreCase("ondc")
                        || orderScreenSelectedDeliveryPartner.equalsIgnoreCase("direct")*/) {
                    checkBox_markAsPacked.setVisibility(View.VISIBLE);
                    checkBox_markAsPacked.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if(isChecked){
                                showProgressDialog("Please wait...");
                                btn_save.setEnabled(false);
                                btn_cancel.setEnabled(false);
                                callMarkAsPacked();
                                checkBox_markAsPacked.setChecked(true);
                                checkBox_markAsPacked.setVisibility(View.GONE);
                            }
                        }
                    });
                }
                else{
                    checkBox_markAsPacked.setChecked(true);
                    checkBox_markAsPacked.setVisibility(View.GONE);
                }
            }   

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String btnName = btn_save.getText().toString();
                if(isFromSalesReturn){
                        if(btnName.equalsIgnoreCase("Return Shipment")
                                && delivery_partner_name.equalsIgnoreCase("direct")){
                            updateReturnStatus(key,appConstant.RETURN_PROCESS_STATES[3]);
                        }
                        else if(btnName.equalsIgnoreCase("search price")
                                && delivery_partner_name.equalsIgnoreCase("ondc")){
                            if(switchPreferred.isChecked()){
                                String select_partner = selectedLogisticsPartner.getSubscriber_id();
                                ondcShipmentPreferredReturn(isCheapest, isFastest, isPreferred, select_partner);
                            }
                            else{
                                ondcShipmentReturn(isCheapest, isFastest);
                            }
                        }
                        else if(btnName.equalsIgnoreCase("Generate Shipment")){
                            if (selectedlogisticsItem != null) {
                                item_id = selectedlogisticsItem.getId();
                                transactionId = selectedlogisticsItem.getCatalog().getTransaction_id();
                                generateReturnQuote(item_id, transactionId);
                            }
                            else {
                                Toast.makeText(getContext(), "request details not available", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(mContext, "Return self", Toast.LENGTH_SHORT).show();
                        }
                }
                else {
                    if (btnName.equalsIgnoreCase("Search Price")) {
                        if (btn_save.getText().toString().equalsIgnoreCase("SEARCH PRICE")
                                && delivery_partner_name.equalsIgnoreCase("ondc")) {
                            if(orderStatus.equalsIgnoreCase("packed")){
                                checkBox_markAsPacked.setChecked(true);
                            }
                            if(checkBox_markAsPacked.isChecked()){
                                if(switchPreferred.isChecked()){
                                    String select_partner = selectedLogisticsPartner.getSubscriber_id();
                                    ondcShipmentPreferredSearch(isCheapest, isFastest, isPreferred, select_partner);
                                }
                                else{
                                    ondcShipmentSearch(isCheapest, isFastest);
                                }
                            }
                            else{
                                Toast.makeText(getActivity(), "Please enable mark as packed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                  /*  else if(btn_save.getText().toString().equalsIgnoreCase("SEARCH PRICE")
                            && switchPreferred.isChecked()){
                        String select_partner = selectedLogisticsPartner.getSubscriber_id();
                        ondcShipmentPreferredSearch(isCheapest, isFastest, isPreferred, select_partner);
                    }
                    else{
                        isSearchCalled = true;
                        if (selectedlogisticsItem != null) {
                            String category = selectedlogisticsItem.getDescriptor().getName();
                            fireForSearchRequest(category, order, deliveryitem, selectedLogisticsPartner);
                        } else {
                            isSearchCalled = false;
                            dismiss();
                            Toast.makeText(getContext(), "Logistics partner not selected", Toast.LENGTH_SHORT).show();
                        }
                    }*/
                } else if (btnName.equalsIgnoreCase("Generate Shipment")) {
                        if (selectedlogisticsItem != null) {
                            item_id = selectedlogisticsItem.getId();
                            transactionId = selectedlogisticsItem.getCatalog().getTransaction_id();
                            mLog.info(selectedlogisticsItem.getProvider_id());
                            mLog.info("Provide: "+selectedlogisticsItem.getProvider().getDescriptor().getName());
                            mLog.info("Amount: " + selectedlogisticsItem.getPrice().getValue());
                            generateShipmentQuote(item_id, transactionId);
//                        if (order != null && deliveryitem != null && selectedLogisticsPartner != null) {
//                            fireForOndcRequest(appConstant.ONDC_LOGISTIC_INIT, logisticsOnSearchData, order, deliveryitem, selectedlogisticsItem);
//                        }
                        }
                        else {
                            Toast.makeText(getContext(), "request details not available", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        if (!delivery_partner_name.equalsIgnoreCase("ondc")) {
                            if(orderStatus.equalsIgnoreCase("packed")){
                                checkBox_markAsPacked.setChecked(true);
                            }
                            if(checkBox_markAsPacked.isChecked()){
                                sendDeliveryDetails.sendDeliveryDetails(delivery_partner_name, strDate);
                                dismiss();
                            }
                            else{
                                Toast.makeText(getActivity(), "Please enable mark as packed.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            if(orderStatus.equalsIgnoreCase("packed")){
                                checkBox_markAsPacked.setChecked(true);
                            }
                            if(checkBox_markAsPacked.isChecked()){
                                if (btn_save.getText().toString().equalsIgnoreCase("CREATE SHIPMENT")
                                        && orderScreenSelectedDeliveryPartner.equalsIgnoreCase("ondc")) {
                                    btn_save.setText("SEARCH PRICE");
                                    if(switchPreferred.isChecked()){
                                        String select_partner = selectedLogisticsPartner.getSubscriber_id();
                                        ondcShipmentPreferredSearch(isCheapest, isFastest, isPreferred, select_partner);
                                    }
                                    else{
                                        ondcShipmentSearch(isCheapest, isFastest);
                                    }
//                                ondcShipmentSearch(isCheapest, isFastest);
                                }
                                else{
                                    Toast.makeText(getContext(), "Please select delivery partner", Toast.LENGTH_SHORT).show();
                                }
                            }
                            else{
                                Toast.makeText(getActivity(), "Please enable mark as packed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendDeliveryDetails.callGetShipmentAPI();
                dismiss();
            }
        });
        getDeliveryPartners();

        deliveryPriceLayout = view.findViewById(R.id.id_delivery_price);
        logisticsPriceRecycler = view.findViewById(R.id.ondc_price_recycler);

        if(orderScreenSelectedDeliveryPartner != null && orderScreenSelectedDeliveryPartner.equalsIgnoreCase("ondc")){
            this.delivery_partner_name = orderScreenSelectedDeliveryPartner;
            btn_save.setText("Search Price"); // ondc search price added here
            setPackageDetail();
        }

        deliveryPriceLayout.setVisibility(View.GONE);
        layoutChooseDate.setVisibility(View.GONE);
        txtSelectedOndcPartner.setVisibility(View.GONE);
        deliveryPriceLayout.setVisibility(View.GONE);
        layoutChooseDate.setVisibility(View.GONE);
    }

    private void generateReturnQuote(String itemId, String transactionId) {
        JSONObject generateJsonObject = new JSONObject();
        try {
            generateJsonObject.put("transaction_id", transactionId);
            generateJsonObject.put("item_id", itemId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        showProgressDialog("Initialize shipment details...");
        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                appConstant.ONDC_SHIPMENT_QUOTE, generateJsonObject, BasicUtils.getSearchONDC_Header(), "ondc_generate_quote_return");
    }

    private void ondcShipmentPreferredReturn(boolean isCheapest, boolean isFastest, boolean isPreferred,
                                             String subscriber_id) {
        try{
            this.order = App.getDB().orderDAO().getOrder(soKey);
//            App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight
//            this.order = App.getDB().deliveryDetailsDataDAO().getOrder(soKey);
//            this.order = App.getDB().deliveryItemDataDAO().getOrder(soKey);
            List<DeliveryItemData> deliveryitemList = new ArrayList<>();
            deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(String.valueOf(diKey));
            if (deliveryitemList.size() > 0) {
                this.deliveryitem = deliveryitemList.get(0);

                height = editTextHeight.getText().toString();
                weight = editTextWeight.getText().toString();
                length = editTextLength.getText().toString();
                breadth = editTextBreadth.getText().toString();

                JSONObject ondcLogisticShipmentSearch = LogisticsUtils.ondcLogisticShipmentPrefReturn(isCheapest,
                        isFastest, isPreferred, order, deliveryitem, subscriber_id, height, weight, length, breadth);
                mLog.info("Logistic Search Request : " + ondcLogisticShipmentSearch);

                showProgressDialog("Fetching price details...");
                VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                        appConstant.ONDC_SHIPMENT_SEARCH, ondcLogisticShipmentSearch, BasicUtils.getSearchONDC_Header(), "ondc_shipment_search");

            } else {
                Toast.makeText(mContext, "Unable to fetch Order Details.", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void ondcShipmentReturn(boolean isCheapest, boolean isFastest) {
        try{
            this.order = App.getDB().orderDAO().getOrder(soKey);
//            List<DeliveryItemData> deliveryitemList = new ArrayList<>();
//            deliveryItemList = App.getDB().deliveryItemDataDAO().getLocalData(String.valueOf(diKey));
            if (deliveryItemList.size() > 0) {
                this.deliveryitem = deliveryItemList.get(0);

                height = editTextHeight.getText().toString();
                weight = editTextWeight.getText().toString();
                length = editTextLength.getText().toString();
                breadth = editTextBreadth.getText().toString();

                JSONObject ondcLogisticShipmentSearch = LogisticsUtils.ondcLogisticShipmentReturn(isCheapest,
                        isFastest, order, deliveryitem, height, weight, length, breadth);
                mLog.info("Logistic Search Request : " + ondcLogisticShipmentSearch);

                showProgressDialog("Fetching price details...");
                VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                        appConstant.ONDC_SHIPMENT_SEARCH, ondcLogisticShipmentSearch, BasicUtils.getSearchONDC_Header(), "ondc_shipment_search");
            } else {
                Toast.makeText(mContext, "Unable to fetch Order Details.", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void updateReturnStatus(int key, String returnProcessState) {
        if (BasicUtils.isNetAvailable()) {
            showProgressDialog(getString(R.string.please_wait));
            JSONObject jsoParam=new JSONObject();
            try {
                jsoParam.put("id", key);
                jsoParam.put("status", returnProcessState);
                jsoParam.put("is_from_buyer", false);
                new VolleyHttpRequest().makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.RETURN_UPDATE_STATUS, jsoParam, BasicUtils.getJsonHeader(), "return_update_status");
            }catch (Exception e){
                e.printStackTrace();
            }
        } else {
            showToast(getString(R.string.no_network_con));
        }
    }

/*
    private void setPackageDetail() {
        try {
            String orderWeight = "0", orderHeight = "0", orderLength = "0", orderBreadth = "0";
            List<DeliveryItemData> deliveryitemList = new ArrayList<>();
            deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
            if (deliveryitemList.size() > 0) {
                this.deliveryitem = deliveryitemList.get(0);
                orderWeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(deliveryitem.getDi_key()));
                orderHeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderHeight(deliveryitem.getDi_key()));
                orderLength = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderLength(deliveryitem.getDi_key()));
                orderBreadth = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderBreadth(deliveryitem.getDi_key()));
            }

            id_view_package.setVisibility(View.VISIBLE);
            linearLengthBreath.setVisibility(View.VISIBLE);
            linearWeightHeight.setVisibility(View.VISIBLE);
            txtPackageDetail.setVisibility(View.VISIBLE);

            double originalWeightValue = Double.parseDouble(orderWeight);
            long roundedWeightValue = Math.round(originalWeightValue);
            String roundedWeightValueString = String.valueOf(roundedWeightValue);

            double originalHeightValue = Double.parseDouble(orderHeight);
            long roundedHeightValue = Math.round(originalHeightValue);
            String roundedHeightValueString = String.valueOf(roundedHeightValue);

            double originalLengthValue = Double.parseDouble(orderLength);
            long roundedLengthValue = Math.round(originalLengthValue);
            String roundedLengthValueString = String.valueOf(roundedLengthValue);

            double originalBreadthValue = Double.parseDouble(orderBreadth);
            long roundedBreadthValue = Math.round(originalBreadthValue);
            String roundedBreadthValueString = String.valueOf(roundedBreadthValue);

            editTextWeight.setText(roundedWeightValueString);
            editTextHeight.setText(roundedHeightValueString);
            editTextLength.setText(roundedLengthValueString);
            editTextBreadth.setText(roundedBreadthValueString);
        }catch (Exception e){
            e.printStackTrace();
        }

    }
*/

    private void setPackageDetail() {
        try {
            double weight = 0, height = 0, length = 0, breadth = 0;
//            String orderWeight = "0", orderHeight = "0", orderLength = "0", orderBreadth = "0";
            if(isFromSalesReturn){
//                deliveryItemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
                if (deliveryItemList.size() > 0) {
                    this.deliveryitem = deliveryItemList.get(0);
                    weight = App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(deliveryitem.getDi_key());
                    height = App.getDB().deliveryDetailsDataDAO().getMaxOrderHeight(deliveryitem.getDi_key());
                    length = App.getDB().deliveryDetailsDataDAO().getMaxOrderLength(deliveryitem.getDi_key());
                    breadth = App.getDB().deliveryDetailsDataDAO().getMaxOrderBreadth(deliveryitem.getDi_key());

                /*orderWeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(deliveryitem.getDi_key()));
                orderHeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderHeight(deliveryitem.getDi_key()));
                orderLength = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderLength(deliveryitem.getDi_key()));
                orderBreadth = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderBreadth(deliveryitem.getDi_key()));*/
                }
            }
            else{
                List<DeliveryItemData> deliveryitemList = new ArrayList<>();
                deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
                if (deliveryitemList.size() > 0) {
                    this.deliveryitem = deliveryitemList.get(0);
                    weight = App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(deliveryitem.getDi_key());
                    height = App.getDB().deliveryDetailsDataDAO().getMaxOrderHeight(deliveryitem.getDi_key());
                    length = App.getDB().deliveryDetailsDataDAO().getMaxOrderLength(deliveryitem.getDi_key());
                    breadth = App.getDB().deliveryDetailsDataDAO().getMaxOrderBreadth(deliveryitem.getDi_key());

                /*orderWeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(deliveryitem.getDi_key()));
                orderHeight = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderHeight(deliveryitem.getDi_key()));
                orderLength = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderLength(deliveryitem.getDi_key()));
                orderBreadth = String.valueOf(App.getDB().deliveryDetailsDataDAO().getMaxOrderBreadth(deliveryitem.getDi_key()));*/
                }
            }


            id_view_package.setVisibility(View.VISIBLE);
            linearLengthBreath.setVisibility(View.VISIBLE);
            linearWeightHeight.setVisibility(View.VISIBLE);
            txtPackageDetail.setVisibility(View.VISIBLE);

          /*  double originalWeightValue = Double.parseDouble(orderWeight);
            long roundedWeightValue = Math.round(originalWeightValue);
            String roundedWeightValueString = String.valueOf(roundedWeightValue);

            double originalHeightValue = Double.parseDouble(orderHeight);
            long roundedHeightValue = Math.round(originalHeightValue);
            String roundedHeightValueString = String.valueOf(roundedHeightValue);

            double originalLengthValue = Double.parseDouble(orderLength);
            long roundedLengthValue = Math.round(originalLengthValue);
            String roundedLengthValueString = String.valueOf(roundedLengthValue);

            double originalBreadthValue = Double.parseDouble(orderBreadth);
            long roundedBreadthValue = Math.round(originalBreadthValue);
            String roundedBreadthValueString = String.valueOf(roundedBreadthValue);

            editTextWeight.setText(roundedWeightValueString);
            editTextHeight.setText(roundedHeightValueString);
            editTextLength.setText(roundedLengthValueString);
            editTextBreadth.setText(roundedBreadthValueString);*/

            editTextWeight.setText(decimalFormat.format(weight));
            editTextHeight.setText(decimalFormat.format(height));
            editTextLength.setText(decimalFormat.format(length));
            editTextBreadth.setText(decimalFormat.format(breadth));
        }catch (Exception e){
            e.printStackTrace();
        }

    }


    boolean isSearchCalled = false;

    @Override
    public void onResume() {
        super.onResume();
        if (isSearchCalled && selectedlogisticsItem == null) {
            isSearchCalled = false;
            dismiss();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void loadLogisticsItems(Map<String, List<LogisticsItem>> providers) {
        if (providers.size() >= 1) {
            String[] keyset = providers.keySet().toArray(new String[0]);
//            selectedProvider = keyset[0];
//            List<LogisticsItem> logisticsItems = providers.get(selectedProvider);
            List<LogisticsItem> logisticsItems = new ArrayList<>();
            for (String key : keyset) {
                if (keyset.length == 1)
                    selectedProvider = keyset[0];
                List<LogisticsItem> items = providers.get(key);
                if (items != null && items.size() > 0)
                    logisticsItems.addAll(items);
            }

           /* for (int i = 0; i < logisticsItems.size(); i++) {
                LogisticsItem mItem = logisticsItems.get(i);
                mItem.setProvider_id(selectedProvider);
                logisticsItems.set(i, mItem);
            }*/
            if (logisticsItems.size() > 0) {
                setupLogisticsItemAdapter(logisticsItems);
            }
        }
        /*else if(providers.size()>1){
//            Toast.makeText(getContext(), "multiple providers list available", Toast.LENGTH_SHORT).show();
            List<LogisticsItem> logisticsItems = new ArrayList<>();
            Type listType = new TypeToken<List<LogisticsItem>>() {
            }.getType();
            providers.values().forEach(item->{
                List<LogisticsItem> mItems = new Gson().fromJson(item.toString(), listType);
                logisticsItems.addAll(mItems);
            });
            if (logisticsItems.size() > 0) {
                setupLogisticsItemAdapter(logisticsItems);
            }
        }*/
        else {
            showToast("Price list unavailable");
        }
    }

    private void showToast(String msg) {
        try {
            Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("Toast error", e.toString());
        }
    }

    private void loadSearchLogisticsItem() {
        List<LogisticsItem> logisticsItems = new ArrayList<>();
//        for (String category : ondc_category) {
//            LogisticsItem item = new LogisticsItem();
//            Descriptor descriptor = new Descriptor();
//            descriptor.setName(category);
//            item.setDescriptor(descriptor);
//            logisticsItems.add(item);
//        }
        if (logisticsItems.size() > 0) {
            setupLogisticsItemAdapter(logisticsItems);
        }
    }

    private void setupLogisticsItemAdapter(List<LogisticsItem> logisticsItemList) {
        if(selectedlogisticsItem == null) {
            if(logisticsItemList.size() > 0)
                selectedlogisticsItem = logisticsItemList.get(0);
        }

        if (displayLogisitcsItemAdapter == null) {
            displayLogisitcsItemAdapter = new DisplayLogisitcsItemAdapter(getContext(), logisticsItemList, this);
//            LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
            GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
            logisticsPriceRecycler.setLayoutManager(layoutManager);
            logisticsPriceRecycler.setAdapter(displayLogisitcsItemAdapter);
        } else {
            displayLogisitcsItemAdapter.updateAdapter(logisticsItemList);
        }
    }

    private void resetOndc() {
        logisticsOnSearchData = new JSONObject();
        deliveryPriceLayout.setVisibility(View.GONE);
        if (displayLogisitcsItemAdapter != null)
            displayLogisitcsItemAdapter.updateAdapter(new ArrayList<>());
        btn_save.setText(getString(R.string.lb_createshipment));
        layoutChooseDate.setVisibility(View.VISIBLE);
        txtSelectedOndcPartner.setText("");
        hideProgressDialog();
    }

    private String getCurrentdate() {
        Calendar cal = Calendar.getInstance();
        int_pYear = cal.get(Calendar.YEAR);
        int_pMonth = cal.get(Calendar.MONTH);
        int_pDay = cal.get(Calendar.DAY_OF_MONTH);
        String curDate = new SimpleDateFormat("dd-MM-yyyy").format(cal.getTime());// get current
        return !TextUtils.isEmpty(curDate) ? curDate : "";
    }

    private void setAdapter(List<ShipmentData> list, int position) {
//        displayshipmentAdapter = new DisplayshipmentAdapter(getContext(), list, false, this);
        displayshipmentAdapter = new DisplayshipmentAdapter(getContext(), list, false, true, position, this);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        delivery_partner_recycler.setLayoutManager(mLinearLayoutManager);
        delivery_partner_recycler.setAdapter(displayshipmentAdapter);
    }

    private void getDeliveryPartners() {
        if (BasicUtils.isNetAvailable()) {
            showProgressDialog("");
            String url = appConstant.getShipment.concat("?country=" + appPreference.getCountryCode());
            new VolleyHttpRequest().makeVolleygetMethod(ShipmentDialogFragment.this, url, new JSONObject(), appConstant.KEY_GET_SHIPMENT);
        }
    }

    @Override
    public void getDeliveryPartnerDetails(String delivery_partner_name) {
//        if(isFromSalesReturn){
//            if(delivery_partner_name.equalsIgnoreCase("ondc")){
//                btn_save.setText("Search Price");
//            }
//            else if(delivery_partner_name.equalsIgnoreCase("direct")){
//                btn_save.setText("Return Shipment");
//            }
//            else{
//                btn_save.setText("Return Shipment");
//            }
//        }
        if (delivery_partner_name.equalsIgnoreCase("ondc")) {
            btn_save.setText("Search Price");
            linearRadioGrp.setVisibility(View.VISIBLE);
//            linearLayoutPackageDetail.setVisibility(View.VISIBLE);
            clearDeliveryPartner();

            this.delivery_partner_name = delivery_partner_name;
          /*  showProgressDialog("Fecthing Ondc Partners...");
            btn_save.setText("Search Price");
            JSONObject jsoParam = new JSONObject();
            try {
//                jsoParam.put("type", "BPP");//staging
                jsoParam.put("type", "sellerApp");//prepod
                jsoParam.put("city", "std:080");
            } catch (JSONException e) {
                Log.e("error",e.toString());
            }
            new VolleyHttpRequest().makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOOKUP, jsoParam, BasicUtils.getDefaultHeader(), "ONDC_LOOKUP");*/
//            deliveryPartnerRadioBtn();
            if(delivery_partner_name.equalsIgnoreCase("ondc")){
                setPackageDetail();
            }
        }
        else if(delivery_partner_name.equalsIgnoreCase("wefast")){
            this.delivery_partner_name = delivery_partner_name;
            resetOndc();
        }
        else {
            this.delivery_partner_name = delivery_partner_name;
            if(delivery_partner_name.equalsIgnoreCase("direct")){
                clearDeliveryPartner();
            }
            linearRadioGrp.setVisibility(View.GONE);
            if(isFromSalesReturn){
                btn_save.setText("Return Shipment");
            }
            else{
                btn_save.setText(getString(R.string.lb_createshipment));
            }
        }
    }

    private void clearDeliveryPartner() {
        txtSelectedOndcPartner.setVisibility(View.GONE);
        deliveryPriceLayout.setVisibility(View.GONE);
        layoutChooseDate.setVisibility(View.GONE);

        id_view_package.setVisibility(View.GONE);
        linearLengthBreath.setVisibility(View.GONE);
        linearWeightHeight.setVisibility(View.GONE);
        txtPackageDetail.setVisibility(View.GONE);

        switchPreferred.setChecked(false);
        switchFastest.setChecked(false);
        switchCheapest.setChecked(false);

        linearLayout_logistic_price.setVisibility(View.GONE);
    }

    private void showPreferredMethod() {
        showProgressDialog("Fetching Ondc Partners...");
        btn_save.setText("Search Price");
        JSONObject jsoParam = new JSONObject();
        try {
//                jsoParam.put("type", "BPP");//staging
            jsoParam.put("type", "sellerApp");//prepod
            jsoParam.put("city", "std:080");
        } catch (JSONException e) {
            Log.e("error", e.toString());
        }
        new VolleyHttpRequest().makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOOKUP, jsoParam, BasicUtils.getDefaultHeader(), "ONDC_LOOKUP");
    }

    private void deliveryPartnerRadioBtn() {

    }

    @Override
    public void handleResult(String method_name, JSONObject response) throws JSONException {
        if (method_name.equalsIgnoreCase(appConstant.KEY_GET_SHIPMENT)) {
            int status_code = response.getInt("statusCode");
            String message = response.getString("message");
            if (status_code == 200 && message.equalsIgnoreCase("success")) {
                JSONArray jsonArray = response.has("data") ? response.getJSONArray("data") : null;
                if (jsonArray == null || jsonArray.length() == 0) {
                    dismiss();
                } else {
                    Type fooType = new TypeToken<List<ShipmentData>>() {
                    }.getType();
                    List<ShipmentData> shipmentDataList = new Gson().fromJson(jsonArray.toString(), fooType);
                    if (shipmentDataList != null) {
                        if (isFromOrderScreen) {
                            if (!TextUtils.isEmpty(orderScreenSelectedDeliveryPartner) && orderScreenSelectedDeliveryPartner.equalsIgnoreCase("ondc")) {
                                setAdapter(shipmentDataList, 1);
//                                getDeliveryPartnerDetails(orderScreenSelectedDeliveryPartner);
                            } else setAdapter(shipmentDataList, -1);
                        } else setAdapter(shipmentDataList, -1);
                    } else {
                        Toast.makeText(getActivity(), "Delivery partners not available", Toast.LENGTH_SHORT).show();
                        dismiss();
                    }
                }
            }
            hideProgressDialog();
        }
        else if (method_name.equalsIgnoreCase("ONDC_LOOKUP")) {
            logisticList = new ArrayList<>();
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonArray = response.getJSONArray("data");
//            LogisticListModel list = new Gson().fromJson(response.getJSONArray("data").toString(), LogisticListModel.class);
            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject = jsonArray.getJSONObject(i);
                LogisticsPartner list = new Gson().fromJson(jsonObject.toString(), LogisticsPartner.class);
                logisticList.add(list);
            }
            Log.i("ONDC", "ONDC" + new Gson().toJson(logisticList));
            hideProgressDialog();
//            dialog.setCancelable(true);
            dialog.showLogisticList(getContext(), logisticList, ondcListener, switchPreferred);

            txtSelectedOndcPartner.setVisibility(View.VISIBLE);

        }
        else if (method_name.equalsIgnoreCase("ondc_logistic_search")) {
            if (BasicUtils.isValidOndcResponse(response)) {
                showProgressDialog("fetching price details...");
//                Toast.makeText(getContext(),"fetching Price details",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "Unable to fetch Logistics Price details", Toast.LENGTH_SHORT).show();
                hideProgressDialog();
            }
        }
        else if (method_name.equalsIgnoreCase("ondc_logistic_select")) {
//            hideProgressDialog();
            Toast.makeText(getContext(), "Fetching Quote List", Toast.LENGTH_SHORT).show();
        }
        else if (method_name.equalsIgnoreCase("ondc_logistic_init")) {
            showProgressDialog("Initialize shipment details...");
        }
        else if (method_name.equalsIgnoreCase("ondc_logistic_track")) {
            showProgressDialog("Fetching shipment track details");
        }
        else if (method_name.equals("getSaleOrders")) {
            int status = response.getInt("status");
            if (status == 1) {
                SalesOrder salesOrder = new Gson().fromJson(response.toString(), SalesOrder.class);
                DeliveryInvoiceModel deliveryInvoiceModel = new DeliveryInvoiceModel(App.getInstance());
                if (salesOrder.getSalesOrder() != null) {

                    if (salesOrder.getSalesOrder().size() > 0) {
                        for (Order order : salesOrder.getSalesOrder()) {
                            if (App.getDB().orderDAO().isOldEntry(order.getSoKey(), order.getExternalOrderNo())) {
                                App.getDB().orderDAO().updateOrder(order);
                            } else {
                                App.getDB().orderDAO().insertOrder(order);
                            }
                            /***** has Bug while getting so Item from server [duplicate item inserting from server] *****/
                            for (OrderItem data : order.getSoItems()) {
                                App.getDB().orderItemDAO().insertOrderItem(data);
                            }
                            for (WalletData data : order.getCustomerWallet()) {
                                App.getDB().walletDataDAO().insertWalletData(data);
                            }

                            if (order.getDi() != null && order.getDi().size() > 0) {
                                deliveryInvoiceModel.upsertDi(order.getDi());
                                List<DeliveryItemData> diList = order.getDi();
                                for (DeliveryItemData di : diList) {
                                    List<DeliveryDetailsData> diItemList = di.getDi_items();
                                    deliveryInvoiceModel.upsertDiItem(diItemList);
                                }
                                if (!TextUtils.isEmpty(di_key)) {
                                    DeliveryItemData deliveryItemData = App.getDB().deliveryItemDataDAO().getDeliveryItembyDI_KEY(di_key);
                                    Displaybill.generatedDIData = deliveryItemData;
                                    ArrayList<DeliveryDetailsData> deliveryDetailsData = (ArrayList<DeliveryDetailsData>) App.getDB().deliveryDetailsDataDAO().getDIDetails(di_key);
                                    if (deliveryItemData != null && deliveryDetailsData != null) {
                                        String storeState = appPreference.getUnitState().replace(" ", "").toLowerCase();
                                        String deliverySate = deliveryItemData.getCus_del_state().replace(" ", "").toLowerCase();
                                        if (!storeState.equalsIgnoreCase(deliverySate))
                                            deliveryItemData.setIsIGSTavialable(1);
                                        else
                                            deliveryItemData.setIsIGSTavialable(0);
                                    }

//                                    JSONObject ondcLogisticRequest = generateOndcLogisticRequest("", order, deliveryItemData);
//                                    mLog.info("Logistic Request : " + ondcLogisticRequest);
//                                    showProgressDialog("");
//                                    VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_SEARCH, ondcLogisticRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_search");
                                }
                            }

                        }
                    }

                    this.order = App.getDB().orderDAO().getOrder(Integer.valueOf(so_key));
                    List<DeliveryItemData> deliveryitemList = new ArrayList<>();
                    deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
                    if (deliveryitemList.size() > 0) {
                        this.deliveryitem = deliveryitemList.get(0);
//                        fireForSearchRequest(order, deliveryitem, selectedLogisticsPartner);
                        loadSearchLogisticsItem();
                    }

                }
            }
        }
        else if (method_name.equalsIgnoreCase("ondc_shipment_search")) {
            deliveryPriceLayout.setVisibility(View.VISIBLE);
            try {
                JSONObject jsonObject = new JSONObject(response.toString());

                if (response.getString("status").equalsIgnoreCase("success")) {
                    JSONArray dataArray = jsonObject.getJSONArray("data");
                    Type listType = new TypeToken<List<LogisticsItem>>() {}.getType();
                    List<LogisticsItem> logisticsItems = new Gson().fromJson(dataArray.toString(), listType);

                    for (int i = 0; i < logisticsItems.size(); i++) {
                        LogisticsItem item = logisticsItems.get(i);
                        String item_id=item.getId();
                        String category_id=item.getCategory_id();
                        String fulfillment_id=item.getFulfillment_id();
                        String parent_item_id=item.getParent_item_id();
                        String price=new Gson().toJson(item.getPrice());
                        String descriptor=new Gson().toJson(item.getDescriptor());
                        String transactionId = new Gson().toJson(item.getCatalog().getTransaction_id());
                        mLog.info("item_id : "+item_id);
                        mLog.info("category_id : "+category_id);
                        mLog.info("fulfillment_id : "+fulfillment_id);
                        mLog.info("parent_item_id : "+parent_item_id);
                        mLog.info("price : "+price);
                        mLog.info("descriptor : "+descriptor);
                        mLog.info("transaction_id : "+ transactionId);

                        setupLogisticsItemAdapter(logisticsItems);

                        hideProgressDialog();
                        btn_save.setText("Generate Shipment");
//                        sendDeliveryDetails.callGetShipmentAPI();
//                        if (btn_save.getText().toString().equalsIgnoreCase("Generate Shipment")) {
//                            btn_save.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                    generateShipmentQuote(item_id, transactionId);
//                                }
//                            });
//                        }
                    }
               /*     if (dataArray.length() > 0) {
                        JSONObject dataObject = dataArray.getJSONObject(0);

                        item_id = dataObject.getString("id");
                        category_id = dataObject.getString("category_id");
                        name = dataObject.getJSONObject("descriptor").getString("name");
                        currency = dataObject.getJSONObject("price").getString("currency");
                        value = dataObject.getJSONObject("price").getString("value");

                        JSONObject providerObject = dataObject.getJSONObject("provider");
                        providerName = providerObject.getJSONObject("descriptor").getString("name");

                        JSONObject catalogObject = dataObject.getJSONObject("catalog");
                        transactionId = catalogObject.getString("transaction_id");

                        JSONObject fulfillmentObject = dataObject.getJSONObject("fulfillment");
                        fulfillment_id = fulfillmentObject.getString("id");

                        transactionId = catalogObject.getString("transaction_id");

                        textView_logistic_partnerName.setText(category_id);
                        textView_logistic_desc_name.setText("Provider : "+providerName + "(Id:"+fulfillment_id+")");
                        textView_logistic_price.setText("Price : " + value + "("+currency+")");
                        linearLayout_logistic_price.setVisibility(View.VISIBLE);
//                        linearLayoutPackageDetail.setVisibility(View.VISIBLE);

                        hideProgressDialog();
                        btn_save.setText("Generate Shipment");
                        if (btn_save.getText().toString().equalsIgnoreCase("Generate Shipment")) {
                            btn_save.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    generateShipmentQuote(item_id, transactionId);
                                }
                            });
                        } else {
                            Toast.makeText(getContext(), "request details not available", Toast.LENGTH_SHORT).show();
                            hideProgressDialog();
                            dismiss();
                        }
                    }*/
                } else {
                    JSONObject errorObject = jsonObject.getJSONObject("error");
                    String errorMessage = errorObject.getString("message");
                    hideProgressDialog();
                    deliveryPriceLayout.setVisibility(View.GONE);
                    Toast.makeText(mContext, errorMessage, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                hideProgressDialog();
                dismiss();
                e.printStackTrace();
            }
        }
        else if (method_name.equalsIgnoreCase("ondc_generate_quote")) {
//            hideProgressDialog();
            JSONObject responseObj = new JSONObject(response.toString());
            try {
                if (response.getString("status").equalsIgnoreCase("success")) {
                    if (responseObj.has("data")) {
                        JSONObject dataObj = responseObj.getJSONObject("data");
//                        if (dataObj.has("message")) {
//                            JSONObject messageObj = dataObj.getJSONObject("message");
//                            if (messageObj.has("order")) {
//                                JSONObject orderObj = messageObj.getJSONObject("order");
//                                if (orderObj.has("items")) {
//                                    JSONArray itemsArray = orderObj.getJSONArray("items");
//                                    if (itemsArray.length() > 0) {
//                                        JSONObject itemObj = itemsArray.getJSONObject(0);
//                                        item_Id = itemObj.getString("id");
//                                    }
//                                }
//                            }
//                        }
                        if (dataObj.has("context")) {
                            transaction_Id = dataObj.getJSONObject("context").getString("transaction_id");
                        }
                    }
                    linearLayout_logistic_price.setVisibility(View.GONE);

                    confirmShipmentQuote(item_id, transaction_Id);

                }
                else {
                    JSONObject errorObject = responseObj.getJSONObject("error");
                    String errorMessage = errorObject.getString("message");
                    hideProgressDialog();
                    dismiss();
                    Toast.makeText(mContext, errorMessage, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                hideProgressDialog();
                dismiss();
                e.printStackTrace();
            }
        }
        else if (method_name.equalsIgnoreCase("ondc_generate_quote_return")) {
//            hideProgressDialog();
            JSONObject responseObj = new JSONObject(response.toString());
            try {
                if (response.getString("status").equalsIgnoreCase("success")) {
                    if (responseObj.has("data")) {
                        JSONObject dataObj = responseObj.getJSONObject("data");
//                        if (dataObj.has("message")) {
//                            JSONObject messageObj = dataObj.getJSONObject("message");
//                            if (messageObj.has("order")) {
//                                JSONObject orderObj = messageObj.getJSONObject("order");
//                                if (orderObj.has("items")) {
//                                    JSONArray itemsArray = orderObj.getJSONArray("items");
//                                    if (itemsArray.length() > 0) {
//                                        JSONObject itemObj = itemsArray.getJSONObject(0);
//                                        item_Id = itemObj.getString("id");
//                                    }
//                                }
//                            }
//                        }
                        if (dataObj.has("context")) {
                            transaction_Id = dataObj.getJSONObject("context").getString("transaction_id");
                        }
                    }
                    linearLayout_logistic_price.setVisibility(View.GONE);

                    confirmReturnQuote(item_id, transaction_Id);

                }
                else {
                    JSONObject errorObject = responseObj.getJSONObject("error");
                    String errorMessage = errorObject.getString("message");
                    hideProgressDialog();
                    dismiss();
                    Toast.makeText(mContext, errorMessage, Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                hideProgressDialog();
                dismiss();
                e.printStackTrace();
            }
        }
        else if (method_name.equalsIgnoreCase("shipment_order_create")) {
            try {
                JSONObject responseJson = new JSONObject(response.toString());
                String status = responseJson.getString("status");
                String data = responseJson.getString("data");
                if (status.equalsIgnoreCase("success") && data.equalsIgnoreCase("null")) {
                    showToast("Order not confirm yet. Please try again after sometimes.");
                }
                else if(status.equalsIgnoreCase("success")){
                    showToast("Shipment created successfully");
                }
                else {
                    showToast("Shipment creation failed");
                }
                sendDeliveryDetails.callGetShipmentAPI();
                hideProgressDialog();
                dismiss();
            }
            catch (Exception e){
                e.printStackTrace();
                hideProgressDialog();
                showToast("Shipment creation failed");
                dismiss();
            }
        }
        else if (method_name.equalsIgnoreCase("return_order_create")) {
            try {
                JSONObject responseJson = new JSONObject(response.toString());
                String status = responseJson.getString("status");
                String data = responseJson.getString("data");
                if (status.equalsIgnoreCase("success") && data.equalsIgnoreCase("null")) {
                    showToast("Order not confirm yet. Please try again after sometimes.");
                }
                else if(status.equalsIgnoreCase("success")){
                    showToast("Return created successfully");
                    sendDeliveryDetails.loadPickedForOndc();
                }
                else {
                    showToast("Return creation failed");
                }
//                sendDeliveryDetails.callGetShipmentAPI();
                hideProgressDialog();
                dismiss();
            }
            catch (Exception e){
                e.printStackTrace();
                hideProgressDialog();
                showToast("Return creation failed");
                dismiss();
            }
        }
        else if(method_name.equalsIgnoreCase("return_update_status")){
            hideProgressDialog();
            String status = JsonDataParser.getStringValueFromJSON(response,"status");
            if(status.equalsIgnoreCase("success")){
                String statusMsg = JsonDataParser.getStringValueFromJSON(response,"message");
                Toast.makeText(getActivity(), statusMsg, Toast.LENGTH_SHORT).show();
                dismiss();
                sendDeliveryDetails.loadReturnShipment();
//                ProcessReturnActivity processReturnActivity = new ProcessReturnActivity();
//                processReturnActivity.fetchReturnRequests(true);
//                ProcessReturnFragment processReturnFragment = new ProcessReturnFragment();
//                processReturnFragment.fetchReturnRequests(true);
//                sendReturnDetails.callDirectReturn();
            }else if(status.equalsIgnoreCase("failure")){
                String statusMsg = JsonDataParser.getStringValueFromJSON(response,"error");
                Toast.makeText(getActivity(), statusMsg, Toast.LENGTH_SHORT).show();
                dismiss();
            }
            else{
                JSONObject error = JsonDataParser.getJsonObject("error");
                String message=JsonDataParser.getStringValueFromJSON(error,"message");
                Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
            }
        }
        else {
            hideProgressDialog();
        }
    }

    private void confirmReturnQuote(String itemId, String transactionId) {
        JSONObject generateJsonObject = new JSONObject();
        try {
            generateJsonObject.put("transaction_id", transactionId);
            generateJsonObject.put("item_id", itemId);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        showProgressDialog("Confirm shipment details...");

        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                appConstant.ONDC_SHIPMENT_CREATE, generateJsonObject,
                BasicUtils.ondcShipmentCreateHeader(), "return_order_create");
    }

    private void startInventorySyncService(Context context) {
        hideProgressDialog();
        if (!BasicUtils.isServicesRunning(InventorySync.class.getSimpleName())) {
            InventorySync.enqueueWork(context, new Intent().putExtra("JOB_ID", InventorySync.RECEIVED_JOB_ID_INVENTORY_SAVE_AND_SYNC));
        } else {
            mLog.severe("InventorySync already running");
        }
    }

    private void ondcShipmentPreferredSearch(boolean isCheapest, boolean isFastest, boolean isPreferred, String subscriber_id) {
        try{
            this.order = App.getDB().orderDAO().getOrder(Integer.valueOf(so_key));
            List<DeliveryItemData> deliveryitemList = new ArrayList<>();
            deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
            if (deliveryitemList.size() > 0) {
                this.deliveryitem = deliveryitemList.get(0);

                height = editTextHeight.getText().toString();
                weight = editTextWeight.getText().toString();
                length = editTextLength.getText().toString();
                breadth = editTextBreadth.getText().toString();

                JSONObject ondcLogisticShipmentSearch = LogisticsUtils.ondcLogisticShipmentPrefSearch(isCheapest,
                        isFastest, isPreferred, order, deliveryitem, subscriber_id, height, weight, length, breadth);
                mLog.info("Logistic Search Request : " + ondcLogisticShipmentSearch);

                showProgressDialog("Fetching price details...");
                VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                        appConstant.ONDC_SHIPMENT_SEARCH, ondcLogisticShipmentSearch, BasicUtils.getSearchONDC_Header(), "ondc_shipment_search");

            } else {
                Toast.makeText(mContext, "Unable to fetch Order Details.", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void generateShipmentQuote(String item_id, String transactionId) {

        JSONObject generateJsonObject = new JSONObject();
        try {
            generateJsonObject.put("transaction_id", transactionId);
            generateJsonObject.put("item_id", item_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        showProgressDialog("Initialize shipment details...");
        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                appConstant.ONDC_SHIPMENT_QUOTE, generateJsonObject, BasicUtils.getSearchONDC_Header(), "ondc_generate_quote");
    }

    private void confirmShipmentQuote(String item_id, String transactionId) {

        JSONObject generateJsonObject = new JSONObject();
        try {
            generateJsonObject.put("transaction_id", transactionId);
            generateJsonObject.put("item_id", item_id);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        showProgressDialog("Confirm shipment details...");

        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                appConstant.ONDC_SHIPMENT_CREATE, generateJsonObject,
                BasicUtils.ondcShipmentCreateHeader(), "shipment_order_create");

//        hideProgressDialog();
//        dismiss();

    }

    @Override
    public void handleResult(String method_name, JSONArray response) throws JSONException {

    }

    @Override
    public void handleError(String method_name, VolleyError e) {
//        Log.e("error",e.toString());
//        try {
//            Log.e("error code", ""+e.networkResponse);
//            Log.e("error code", ""+e.networkResponse.statusCode);
//        }catch (Exception ee){
//            eLog.e("error",e.toString());
//        }
//        Log.e("error data",e.networkResponse.data.toString());

        if (method_name.equalsIgnoreCase("ONDC_SEARCH")) {
            hideProgressDialog();
            Toast.makeText(getContext(), "Logistic price details not available", Toast.LENGTH_SHORT).show();
            dismiss();
        }
        if (method_name.equalsIgnoreCase("ONDC_LOOKUP")) {
            hideProgressDialog();
            Toast.makeText(getContext(), "Logistic partners not available", Toast.LENGTH_SHORT).show();
            dismiss();
        }
        if (method_name.equalsIgnoreCase("ondc_logistic_search")) {
            hideProgressDialog();
            Toast.makeText(getContext(), "Unable to search logistic price details.", Toast.LENGTH_SHORT).show();
            dismiss();
        } else if (method_name.equalsIgnoreCase("ondc_logistic_select")) {
            hideProgressDialog();
            Toast.makeText(getContext(), "Unable to select shipment details.", Toast.LENGTH_SHORT).show();
        }
//        else if (method_name.equalsIgnoreCase("ondc_logistic_init")) {
//            Toast.makeText(getContext(), "Unable to generate shipment quote.", Toast.LENGTH_SHORT).show();
//        }
//        else if (method_name.equalsIgnoreCase("ondc_logistic_confirm")) {
//            Toast.makeText(getContext(), "Unable to confirm shipment.", Toast.LENGTH_SHORT).show();
//        }
        else if (method_name.equalsIgnoreCase("ondc_logistic_status")) {
            Toast.makeText(getContext(), "Unable to fetch shipment status.", Toast.LENGTH_SHORT).show();
        } else if (method_name.equalsIgnoreCase("ondc_logistic_track")) {
            Toast.makeText(getContext(), "Unable to track shipment details.", Toast.LENGTH_SHORT).show();
        }
        else if (method_name.equalsIgnoreCase("ondc_shipment_confirm")) {
            Toast.makeText(getContext(), "Unable to shipment confirm.", Toast.LENGTH_SHORT).show();
        }
        else if (method_name.equalsIgnoreCase("shipment_order_create")) {
            Toast.makeText(getContext(), "Unable to generate shipment.", Toast.LENGTH_SHORT).show();
            dismiss();
        }
        else if (method_name.equalsIgnoreCase("return_order_create")) {
            Toast.makeText(getContext(), "Unable to generate shipment.", Toast.LENGTH_SHORT).show();
            dismiss();
        }

    }

    @Override
    public void onLogisticsSelected(LogisticsPartner logisticsPartner) {
        if(isFromSalesReturn){
            returnLogisticsSelect(diKey, soKey, logisticsPartner);
        }
        else{
            shipmentLogisticsSelect(di_key, so_key, logisticsPartner);
        }
    }

    private void shipmentLogisticsSelect(String diKey, String soKey, LogisticsPartner logisticsPartner) {
        dialog.dismiss();
        LogisticsUtils logisticsUtils = new LogisticsUtils();
        partner_name = logisticsUtils.getOndcPartnerName(logisticsPartner.getSubscriber_id());
        txtSelectedOndcPartner.setText("Selected Ondc Partner : " + partner_name);
        this.selectedLogisticsPartner = logisticsPartner;
        this.order = App.getDB().orderDAO().getOrder(soKey);
        List<DeliveryItemData> deliveryitemList = new ArrayList<>();
        deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(String.valueOf(diKey));
        if (deliveryitemList.size() > 0) {
            this.deliveryitem = deliveryitemList.get(0);
            loadSearchLogisticsItem();
        }
        else {
            showProgressDialog("");
            fireForOrder(so_key);
        }
    }

    private void returnLogisticsSelect(int diKey, int soKey, LogisticsPartner logisticsPartner) {
        dialog.dismiss();
        LogisticsUtils logisticsUtils = new LogisticsUtils();
        partner_name = logisticsUtils.getOndcPartnerName(logisticsPartner.getSubscriber_id());
        txtSelectedOndcPartner.setText("Selected Ondc Partner : " + partner_name);
        this.selectedLogisticsPartner = logisticsPartner;
        this.order = App.getDB().orderDAO().getOrder(soKey);
        List<DeliveryItemData> deliveryitemList = new ArrayList<>();
        deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(String.valueOf(diKey));
        if (deliveryitemList.size() > 0) {
            this.deliveryitem = deliveryitemList.get(0);
            loadSearchLogisticsItem();
        }
        else {
            showProgressDialog("");
            fireForOrder(so_key);
        }
    }

    private void ondcShipmentSearch(boolean cheapest, boolean fastest) {
        try{
            this.order = App.getDB().orderDAO().getOrder(Integer.valueOf(so_key));
            List<DeliveryItemData> deliveryitemList = new ArrayList<>();
            deliveryitemList = App.getDB().deliveryItemDataDAO().getLocalData(di_key);
            if (deliveryitemList.size() > 0) {
                this.deliveryitem = deliveryitemList.get(0);

                height = editTextHeight.getText().toString();
                weight = editTextWeight.getText().toString();
                length = editTextLength.getText().toString();
                breadth = editTextBreadth.getText().toString();

                JSONObject ondcLogisticShipmentSearch = LogisticsUtils.ondcLogisticShipmentSearch(cheapest,
                        fastest, order, deliveryitem, height, weight, length, breadth);
                mLog.info("Logistic Search Request : " + ondcLogisticShipmentSearch);

                showProgressDialog("Fetching price details...");
                VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this,
                        appConstant.ONDC_SHIPMENT_SEARCH, ondcLogisticShipmentSearch, BasicUtils.getSearchONDC_Header(), "ondc_shipment_search");
            } else {
                Toast.makeText(mContext, "Unable to fetch Order Details.", Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public interface SendDeliveryDetails {
        void sendDeliveryDetails(String partner_name, String shipment_date);

        void sendOndcDeliveryDetails(String partner_name, String bpp_id, String bpp_uri, JSONObject shipmentOrder, String amount, JSONObject onTrackData);

        void callGetShipmentAPI();

        //        void callShipmentCreateApi(JSONObject jsonObjectConfirm);
        void callShipmentCreateApi(String delivery_partner_name);
        void loadReturnShipment();

        void loadPickedForOndc();
    }

    public interface SendReturnDetails {
        void callDirectReturn();
        void callDirectSalesReturn(String key, String returnProcessState);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        sendDeliveryDetails = (SendDeliveryDetails) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
//        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(mLogisticsReceiver);
        hideProgressDialog();
    }

    @Override
    public void onLogisticsItemSelected(LogisticsItem logisticsItem) {
        this.selectedlogisticsItem = logisticsItem;
    }

    @Override
    public void onSelectLogisticItem(LogisticsItem logisticsItem) {
        this.selectedlogisticsItem = logisticsItem;
    }

    private void showProgressDialog(String strMessage) {
        try {
            progressBar.setVisibility(View.VISIBLE);
            if (!TextUtils.isEmpty(strMessage)) txtProgress.setText(strMessage);
            else txtProgress.setText("");
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
    }

    private void hideProgressDialog() {
        try {
            if (progressBar != null && progressBar.getVisibility() == View.VISIBLE) {
                progressBar.setVisibility(View.GONE);
                txtProgress.setText("");
            }
        } catch (Exception e) {
            Log.e("error", e.toString());
        }
    }

    private void fireForSearchRequest(String category, Order order, DeliveryItemData di, LogisticsPartner logisticsPartner) {
        JSONObject ondcLogisticRequest = LogisticsUtils.ondcLogisticSearchRequest("", category, order, di, logisticsPartner);
        mLog.info("Logistic Search Request : " + ondcLogisticRequest);
        showProgressDialog("Fetching price details...");
        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_SEARCH, ondcLogisticRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_search");
    }

    /*private void fireForSelectRequest(Order order,DeliveryItemData di,LogisticsPartner logisticsPartner,LogisticsItem item){
        JSONObject ondcLogisticRequest = LogisticsUtils.ondcLogisticItemRequest("",order,  di,logisticsPartner,item);
        mLog.info("Logistic Select Request  : " + ondcLogisticRequest);
        showProgressDialog("");
        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_SELECT, ondcLogisticRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_select");
    }*/

    private void fireForOndcRequest(String api, JSONObject data, Order order, DeliveryItemData di, LogisticsItem item) {
        JSONObject context = LogisticsUtils.getContext(data);
        JSONObject message = LogisticsUtils.getMessage(data);
        if (context != null && message != null) {
            String bpp_id = JsonDataParser.getStringValueFromJSON(context, "bpp_id");
            String bpp_uri = JsonDataParser.getStringValueFromJSON(context, "bpp_uri");
            String message_id = JsonDataParser.getStringValueFromJSON(context, "message_id");
            String transaction_id = JsonDataParser.getStringValueFromJSON(context, "transaction_id");
            String payment_type = LogisticsUtils.payment_type[0];
            if (order.getPaymentMode().equalsIgnoreCase("online") || order.getPaymentMode().equalsIgnoreCase("card")) {
                payment_type = LogisticsUtils.payment_type[1];
            }

            if (!TextUtils.isEmpty(bpp_id) && !TextUtils.isEmpty(bpp_uri) && !TextUtils.isEmpty(message_id) && !TextUtils.isEmpty(transaction_id)) {
                JSONObject ondcLogisticRequest = LogisticsUtils.ondcLogisticItemRequest(transaction_id, message_id, bpp_id, bpp_uri, payment_type, order, di, item);
                mLog.info("Logistic Request  : " + ondcLogisticRequest);
                if (api.equalsIgnoreCase(appConstant.ONDC_LOGISTIC_INIT)) {
                    try {
                        ondcLogisticRequest.put("settlement_details", LogisticsUtils.getPaymentSettlementDetails(BuildConfig.BPP_SETTLEMENT_TYPE));
                        showProgressDialog("Initialize shipment details...");
                        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_INIT, ondcLogisticRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_init");
                    } catch (Exception e) {
                        Log.e("error", e.toString());
                        hideProgressDialog();
                        Toast.makeText(getContext(), "unable to Init quote", Toast.LENGTH_SHORT).show();
                    }
                } else if (api.equalsIgnoreCase(appConstant.ONDC_LOGISTIC_CONFIRM)) {
                    JSONObject mInitOrder = JsonDataParser.getJsonValueFromJSON(message, "order");
                    JSONObject mInitPayment = JsonDataParser.getJsonValueFromJSON(mInitOrder, "payment");
                    JSONObject mInitQuote = JsonDataParser.getJsonValueFromJSON(mInitOrder, "quote");
                    JSONObject mInitProvider = JsonDataParser.getJsonValueFromJSON(mInitOrder, "provider");

                    JSONObject mInitProviderLocation = JsonDataParser.getJsonValueFromJSON(mInitOrder, "provider_location");
                    String location_id = "";
                    if (mInitProviderLocation != null)
                        location_id = JsonDataParser.getStringValueFromJSON(mInitProviderLocation, "id");
                    try {
                        JSONArray providerLocationAry = new JSONArray();
                        JSONObject providerLocationObj = new JSONObject();
                        providerLocationObj.put("id", location_id);
                        providerLocationAry.put(providerLocationObj);

                        mInitProvider.put("locations", providerLocationAry);

                        ondcLogisticRequest.put("provider", mInitProvider);

                        if (mInitPayment != null) {
                            if (!mInitPayment.has("@ondc/org/collection_amount"))
                                mInitPayment.put("@ondc/org/collection_amount", String.valueOf(di.getTotal_amount()));
                            ondcLogisticRequest.put("payment", mInitPayment);
                        } else {
                            mInitPayment = new JSONObject();
                            try {
                                mInitPayment.put("@ondc/org/collection_amount", String.valueOf(di.getTotal_amount()));
                                ondcLogisticRequest.put("payment", mInitPayment);
                            } catch (Exception e) {
                                Log.e("error", e.toString());
                            }
                        }
                        ondcLogisticRequest.put("quote", mInitQuote);

                        List<DeliveryDetailsData> di_details = App.getDB().deliveryDetailsDataDAO().getDIDetails(String.valueOf(di.getDi_key()));

                        JSONObject linked_order = new JSONObject();
                        JSONObject mOrder = new JSONObject();
                        JSONArray order_items = new JSONArray();
                        try {
                            String unit_type = appPreference.getUnitType();

                            if (TextUtils.isEmpty(unit_type))
                                unit_type = "Packaged Commodities";

                            for (DeliveryDetailsData di_item : di_details) {

                                String productName = di_item.getProduct_name();
                                String price = String.valueOf(di_item.getItem_total());
                                int qty = (int) di_item.getQty();

                                JSONObject jsoItem = new JSONObject();
                                jsoItem.put("category_id", unit_type);

                                JSONObject jsoDescriptor = new JSONObject();
                                jsoDescriptor.put("name", productName);
                                jsoItem.put("descriptor", jsoDescriptor);

                                JSONObject jsoQuantity = new JSONObject();
                                jsoQuantity.put("count", qty);

                                double itemWeight = App.getDB().deliveryDetailsDataDAO().getItemOrderWeight(di_item.getDi_key(), di_item.getDid_u_key());
                                if (itemWeight == 0) itemWeight = 1;

                                JSONObject jsoMeasure = new JSONObject();
                                jsoMeasure.put("unit", "Kilogram");
                                jsoMeasure.put("value", itemWeight);
                                jsoQuantity.put("measure", jsoMeasure);
                                jsoItem.put("quantity", jsoQuantity);

                                JSONObject jsoPrice = new JSONObject();
                                jsoPrice.put("currency", "INR");
                                jsoPrice.put("value", price);
                                jsoItem.put("price", jsoPrice);

                                order_items.put(jsoItem);
                            }

//                            int quantity= di_details.size()*LogisticsUtils.DEFAULT_ORDER_QUANTITY;
                            double maxOrderWeight = App.getDB().deliveryDetailsDataDAO().getMaxOrderWeight(di.getDi_key());
                            if (maxOrderWeight == 0)
                                maxOrderWeight = 1;
                            JSONObject weight = new JSONObject();
                            weight.put("unit", "Kilogram");
                            weight.put("value", maxOrderWeight);
                            mOrder.put("weight", weight);

                            String order_id = order.getExternalOrderNo();

                            mLog.config("External order id " + order_id);
                            mLog.config("Virtual order id " + order.getVirtual_order_no());
                            mLog.config("source order id " + order.getSource_order_id());

                            if (!TextUtils.isEmpty(order.getOndc_order_id())) {
                                mOrder.put("id", order.getOndc_order_id());
                            } else
                                mOrder.put("id", order_id);

                        } catch (Exception e) {
                            Log.e("error", e.toString());
                        }

                        linked_order.put("items", order_items);
                        linked_order.put("order", mOrder);

                        ondcLogisticRequest.put("linked_order", linked_order);


                        showProgressDialog("Confirm shipment details...");
                        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_CONFIRM, ondcLogisticRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_confirm");
                    } catch (Exception e) {
                        Log.e("error", e.toString());
                        hideProgressDialog();
                        Toast.makeText(getActivity(), "unable to generate quote", Toast.LENGTH_SHORT).show();
                    }
                } else if (api.equalsIgnoreCase(appConstant.ONDC_LOGISTIC_STATUS)) {
                    try {
                        showProgressDialog("Requesting shipment track details...");
                        String[] trans_ids = transaction_id.split("_");
                        String order_id = trans_ids[0].concat("_").concat(trans_ids[1]).concat("_").concat(trans_ids[2]);
                        JSONObject ondcLogisticTrackRequest = LogisticsUtils.ondcLogisticTrackRequest(transaction_id, message_id, bpp_id, bpp_uri, order_id);
                        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_STATUS, ondcLogisticTrackRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_status");
                    } catch (Exception e) {
                        Log.e("error", e.toString());
                        hideProgressDialog();
                        Toast.makeText(getActivity(), "unable to generate Track request", Toast.LENGTH_SHORT).show();
                    }
                } else if (api.equalsIgnoreCase(appConstant.ONDC_LOGISTIC_TRACK)) {
                    try {
                        showProgressDialog("Requesting shipment track details...");
                        String[] trans_ids = transaction_id.split("_");
                        String order_id = trans_ids[0].concat("_").concat(trans_ids[1]).concat("_").concat(trans_ids[2]);
                        JSONObject ondcLogisticTrackRequest = LogisticsUtils.ondcLogisticTrackRequest(transaction_id, message_id, bpp_id, bpp_uri, order_id);
                        VolleyHttpRequest.makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.ONDC_LOGISTIC_TRACK, ondcLogisticTrackRequest, BasicUtils.getDefaultHeader(), "ondc_logistic_track");
                    } catch (Exception e) {
                        Log.e("error", e.toString());
                        hideProgressDialog();
                        Toast.makeText(getActivity(), "unable to generate Track request", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    hideProgressDialog();
                    Toast.makeText(getActivity(), "unable to generate quote", Toast.LENGTH_SHORT).show();
                }
            } else {
                hideProgressDialog();
                Toast.makeText(getActivity(), "unable to generate quote", Toast.LENGTH_SHORT).show();
            }
        } else {
            hideProgressDialog();
            Toast.makeText(getActivity(), "unable to generate shipment", Toast.LENGTH_SHORT).show();
        }
    }

    private void fireForOrder(String so_key) {
        if (BasicUtils.isNetAvailable()) {
            showProgressDialog("");
            boolean isVso = appPreference.getIsvso().equalsIgnoreCase("true");

            JSONObject mJsParm = new JSONObject();
            try {
                mJsParm.put("current_id", so_key);
                mJsParm.put("modified_on", "");
            } catch (Exception e) {
                Log.e("error", e.toString());
            }

            if (isVso)
                new VolleyHttpRequest().makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.GET_VIRTUAL_SALE_ORDER_URL, mJsParm, BasicUtils.getJsonHeader(), "getSaleOrders");
            else
                new VolleyHttpRequest().makeVolleyPostHeader(ShipmentDialogFragment.this, appConstant.GET_SALE_ORDER_URL, mJsParm, BasicUtils.getJsonHeader(), "getSaleOrders");
        } else {
            Toast.makeText(getActivity(), "Connection not available,Saved Locally", Toast.LENGTH_SHORT).show();
        }
    }

    private void callMarkAsPacked() {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(deliveryitemList.get(orderPosition).getInvoice_no());

        JSONObject mjsParm = new JSONObject();
        try {
            mjsParm.put("unit_key",appPreference.getUnitKey());
            mjsParm.put("status","017");
            mjsParm.put("invoices",jsonArray);
        } catch (JSONException e) {
            Log.e("error",e.toString());
        }

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.POST, appConstant.UPDATE_INVOICE_STATUS, mjsParm, response -> {
            try {
                int status = response.getInt("statusCode");
                String message = response.getString("message");
                if (status == 200 && message.equalsIgnoreCase("success")) {
//                            deliveryDataArrayList.get(selectedPosition).setStatus("Packed");
//                            createTrackShipmentAdapter.notifyDataSetChanged();
                    btn_save.setEnabled(true);
                    btn_cancel.setEnabled(true);
                    Toast.makeText(getActivity(),"Mark as Packed Successfully.",Toast.LENGTH_SHORT).show();
                    checkBox_markAsPacked.setChecked(true);
                    checkBox_markAsPacked.setVisibility(View.GONE);
                } else {
                    Toast.makeText(getActivity(),R.string.error_msg,Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
                hideProgressDialog();
            } catch (JSONException e) {
                Log.e("error",e.toString());
            }
        }, error -> {
            dialog.dismiss();
            hideProgressDialog();
            Toast.makeText(getActivity(),R.string.error_msg,Toast.LENGTH_SHORT).show();
        });
        jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(60 * 1000,
                1,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        App.getINSTANCE().addRequestQueue(jsonObjReq);
        App.getINSTANCE().getRequestQueue().getCache().remove(appConstant.UPDATE_INVOICE_STATUS);
        App.getINSTANCE().getRequestQueue().getCache().clear();
    }

}