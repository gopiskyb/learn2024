/*console.log(45 === 45.0);
console.log(0.1 + 0.2);

console.log(0.1 + 0.2 === 0.3);

let x = 1000000000;
console.log(x);

let billion = 1_000_000_000;
console.log(billion);

let y = 23e9;
console.log(y);

let z = 23e-5;
console.log(z);

let a = 0b11111111;
let b = 0o377;
let c = 0xff;

console.log(a);
console.log(b);
console.log(c);*/

/*let num = 255;
console.log(num.toString());
console.log(num.toString(2)); //binary form
console.log(num.toString(8)); //octal form
console.log(num.toString(16)); //hexadecimal form*/

/*console.log(Number('22'));
console.log(+'22');

console.log(+'22GN');
console.log(Number('GN22'));*/

/*console.log(parseInt('12AC')); // working like int to start
console.log(parseInt('120Kg')); // working like int to start
console.log(parseFloat('22.8Cm'));*/

// console.log(parseInt('ABD17Runs')); // Nan will occur // string will starting so not working

/*console.log(isNaN('15')); // is number so false is NOT
console.log(isNaN('A2B')); // letter start so true is NAN
console.log(NaN === NaN);*/

//isFinite how's work

/*console.log(isFinite("16"));
console.log(isFinite("16.20"));
console.log(isFinite("16.5cm"));
console.log(isFinite(Infinity));*/

// Integer how's works

// console.log(Number.isInteger("22"));
// console.log(Number.isInteger(22));
// console.log(Number.isInteger('22A'));

console.log(Math.PI); // RETURN THE VALUE OF MATHEMATICAL PI
console.log(Math.SQRT2); // RETURN THE VALUE OF SQRT OF 2
console.log(Math.SQRT1_2); //RETURN THE VALUE OF SQRT OF 1/2

// RETURN THE NEAREST INTEGER
console.log(Math.round(2.987));
console.log(Math.round(2.087));
console.log(Math.round(-0.56));

// ROUND UP THE VALUE TO ITS NEAREST INTEGER
console.log(Math.ceil(1.0100));
console.log(Math.ceil(2.567));

// ROUND DOWN THE VALUE TO ITS NEAREST INTEGER
console.log(Math.floor(0.98));
console.log(Math.floor(1.98));

// RETURN THE INTEGER PART FROM A FRACTIONAL NUMBER
console.log(Math.trunc(3.24));
console.log(Math.trunc(0.24));

// RETURN THE SQUARE ROOT OF A GIVEN NUMBER
console.log(Math.sqrt(36));
console.log(Math.sqrt(64));

// RETURN THE MAXIMUM VALUE OF FROM A GIVEN NUMBER
console.log(Math.max(1,10,23,22,45,1322,8,77,88,888,999,1111));
console.log(Math.min(1,10,23,22,45,0,8,77,88,888,999,1111));

// RETURN THE MINIMUM VALUE OF FROM A GIVEN NUMBER
console.log(Math.min(1,10,23,22,45,'0px',8,77,88,888,999,1111));
console.log(Math.min(1,10,23,22,45,0,8,77,88,888,999,'1111'));

//RETURN A RANDOM VALUE BETWEEN 0 & 1
console.log(Math.random());
console.log(Math.trunc(Math.random() * 10 + 1));